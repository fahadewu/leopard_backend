const express = require('express');
const router = express.Router();
const { upload } = require('../middleware/upload');
const { authMiddleware } = require('../middleware/auth');
const path = require('path');
const fs = require('fs');

// Helper function to generate the correct base URL
const getBaseUrl = (req) => {
  // Use environment variable if set, otherwise construct from request
  const baseUrl = process.env.BACKEND_BASE_URL || `${req.protocol}://${req.get('host')}`;
  // Force HTTPS in production
  if (process.env.NODE_ENV === 'production' && baseUrl.startsWith('http://')) {
    return baseUrl.replace('http://', 'https://');
  }
  return baseUrl;
};

// Upload single image
router.post('/single', authMiddleware, upload.single('image'), (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ 
        success: false, 
        message: 'No file uploaded' 
      });
    }

    // Return the file path
    const filePath = req.file.path.replace(/\\/g, '/'); // Normalize path separators
    const publicPath = '/' + filePath; // Make it accessible via URL

    res.json({
      success: true,
      message: 'File uploaded successfully',
      data: {
        filename: req.file.filename,
        originalname: req.file.originalname,
        mimetype: req.file.mimetype,
        size: req.file.size,
        path: publicPath,
        url: `${getBaseUrl(req)}${publicPath}`
      }
    });
  } catch (error) {
    console.error('Upload error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Failed to upload file',
      error: error.message 
    });
  }
});

// Upload profile image
router.post('/profile', authMiddleware, upload.single('profile_image'), (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ 
        success: false, 
        message: 'No profile image uploaded' 
      });
    }

    const filePath = req.file.path.replace(/\\/g, '/');
    const publicPath = '/' + filePath;

    res.json({
      success: true,
      message: 'Profile image uploaded successfully',
      data: {
        filename: req.file.filename,
        path: publicPath,
        url: `${getBaseUrl(req)}${publicPath}`
      }
    });
  } catch (error) {
    console.error('Profile image upload error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Failed to upload profile image',
      error: error.message 
    });
  }
});

// Upload project image
router.post('/project', authMiddleware, upload.single('project_image'), (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ 
        success: false, 
        message: 'No project image uploaded' 
      });
    }

    const filePath = req.file.path.replace(/\\/g, '/');
    const publicPath = '/' + filePath;

    res.json({
      success: true,
      message: 'Project image uploaded successfully',
      data: {
        filename: req.file.filename,
        path: publicPath,
        url: `${getBaseUrl(req)}${publicPath}`
      }
    });
  } catch (error) {
    console.error('Project image upload error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Failed to upload project image',
      error: error.message 
    });
  }
});

// Upload gallery image
router.post('/gallery', authMiddleware, upload.single('gallery_image'), (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ 
        success: false, 
        message: 'No gallery image uploaded' 
      });
    }

    const filePath = req.file.path.replace(/\\/g, '/');
    const publicPath = '/' + filePath;

    res.json({
      success: true,
      message: 'Gallery image uploaded successfully',
      data: {
        filename: req.file.filename,
        path: publicPath,
        url: `${getBaseUrl(req)}${publicPath}`
      }
    });
  } catch (error) {
    console.error('Gallery image upload error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Failed to upload gallery image',
      error: error.message 
    });
  }
});

// Upload testimonial avatar
router.post('/testimonial', authMiddleware, upload.single('testimonial_avatar'), (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ 
        success: false, 
        message: 'No testimonial avatar uploaded' 
      });
    }

    const filePath = req.file.path.replace(/\\/g, '/');
    const publicPath = '/' + filePath;

    res.json({
      success: true,
      message: 'Testimonial avatar uploaded successfully',
      data: {
        filename: req.file.filename,
        path: publicPath,
        url: `${getBaseUrl(req)}${publicPath}`
      }
    });
  } catch (error) {
    console.error('Testimonial avatar upload error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Failed to upload testimonial avatar',
      error: error.message 
    });
  }
});

// Delete uploaded file
router.delete('/:filename', authMiddleware, (req, res) => {
  try {
    const filename = req.params.filename;
    const filePath = path.join(__dirname, '../uploads', filename);

    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
      res.json({
        success: true,
        message: 'File deleted successfully'
      });
    } else {
      res.status(404).json({
        success: false,
        message: 'File not found'
      });
    }
  } catch (error) {
    console.error('File deletion error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to delete file',
      error: error.message
    });
  }
});

module.exports = router;